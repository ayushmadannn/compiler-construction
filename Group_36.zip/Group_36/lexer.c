/*
            ******GROUP NUMBER 36*******
            AKSHAT AGRAWAL 2020A7PS0994P
            MADHAV GUPTA   2020A7PS0106P
            ANISH GUPTA    2020A7PS2051P
            AYUSH MADAN    2020A7PS0090P
*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "lexer.h"
#include "hashtable.c"


void populate_lexer_table() {
  insert(token_table,"integer", INTEGER);
  insert(token_table,"real", REAL);
  insert(token_table,"boolean", BOOLEAN);
  insert(token_table,"of", OF);
  insert(token_table,"array", ARRAY);
  insert(token_table,"start", START);
  insert(token_table,"end", END);
  insert(token_table,"declare", DECLARE);
  insert(token_table,"module", MODULE);
  insert(token_table,"driver", DRIVER);
  insert(token_table,"program", PROGRAM);
  insert(token_table,"get_value", GET_VALUE);
  insert(token_table,"print", PRINT);
  insert(token_table,"use", USE);
  insert(token_table,"with", WITH);
  insert(token_table,"parameters", PARAMETERS);
  insert(token_table,"true", TRUE);
  insert(token_table,"false", FALSE);
  insert(token_table,"takes", TAKES);
  insert(token_table,"input", INPUT);
  insert(token_table,"returns", RETURNS);
  insert(token_table,"and", AND);
  insert(token_table,"or", OR);
  insert(token_table,"AND", AND);
  insert(token_table,"OR", OR);
  insert(token_table,"for", FOR);
  insert(token_table,"in", IN);
  insert(token_table,"switch", SWITCH);
  insert(token_table,"case", CASE);
  insert(token_table,"break", BREAK);
  insert(token_table,"default", DEFAULT);
  insert(token_table,"while", WHILE);
}

void retract(int number) {
    current_ptr = current_ptr - number;
    if(current_ptr<0){
        current_ptr = current_ptr + BUFFER_SIZE;
        retractf = 1;
        flag = 1-flag;
    }
}

void fill_buffer(FILE *fp){
    int size;
    if(flag){
        memset(Buffer1,0,sizeof(Buffer1));
        fread(Buffer1,1, BUFFER_SIZE, fp);
    }
    else{
        memset(Buffer2,0,sizeof(Buffer2));
        fread(Buffer2,1, BUFFER_SIZE, fp);
    }
    flag = 1-flag;
}

char get_char(FILE *fp){

    if(current_ptr == BUFFER_SIZE && retractf==0){
        fill_buffer(fp);

        current_ptr=0;
    }
    else if(current_ptr == BUFFER_SIZE && retractf==1){
        retractf=0;
    }
    

    char c;
    if(flag == 1){
        c = Buffer2[current_ptr];
    }
    else{
        c = Buffer1[current_ptr];
        
    }
    current_ptr++;
    return c;
}

TOKEN get_next_token(FILE *fp) {
    char c;
    TOKEN tkn;
    while(true){
        tkn.lineno=line_no;
        switch(state){

            case 0:;
            c=get_char(fp);
            if(isalpha(c)||c=='_')state=1;
            else if(isdigit(c)) state=2;
            else if(c=='+') state=9;
            else if(c=='-') state=10;
            else if(c=='*') state=11;
            else if(c=='/') state=15;
            else if(c=='<') state=16;
            else if(c=='>') state=20;
            else if(c=='=') state=24;
            else if(c=='!') state=26;
            else if(c==':') state=28;
            else if(c=='.') state=30;
            else if(c==';') state=32;
            else if(c==',') state=33;
            else if(c=='[') state=34;
            else if(c==']') state=35;
            else if(c=='(') state=36;
            else if(c==')') state=37;
            else if(c=='\n') {
                line_no++;
                start_ptr++;
                state=0;
            }
            else if(c=='\t'){
                start_ptr++;
                state=0;
                }
            else if(c==' ') {
                state=0;
                start_ptr++;
            }
            else if(feof(fp)){
                state=49;
            }
            else {
                state=50;
                current_ptr++;
            }
            break;

            case 1:;
            c=get_char(fp);
            if(isalpha(c)||isdigit(c)||c=='_') {
                state=1;
            }
            else {
                retract(1);
                tkn.lineno = line_no;
                int size = current_ptr- start_ptr;
                if(size<0){
                    size += BUFFER_SIZE;
                    if(flag==0){
                        strncpy(lexeme, Buffer2 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer1, current_ptr);
                    }
                    else{
                        strncpy(lexeme, Buffer1 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer2, current_ptr);
                    }
                }
                else{
                    if(flag){
                        strncpy(lexeme,Buffer2+start_ptr, current_ptr-start_ptr);
                    }
                    else{
                        strncpy(lexeme,Buffer1+ start_ptr, current_ptr-start_ptr);
                    }
                }
                //printf("%s",lexeme);
                if(size>20){
                    tkn.name = LEX_ERROR;
                    strncpy(tkn.v.lexeme, lexeme, MAX_LEX_ERROR);   
                }
                else{
                    symbol_name name = search(token_table,lexeme);
                    
                    tkn.name = name;
                    strncpy(tkn.v.lexeme, lexeme, MAX_LEXEME_LENGTH);
                    if(tkn.name == KEY_NOT_FOUND){
                        tkn.name = ID;
                    }
                }
                start_ptr = current_ptr;
                state = 0;
                memset(lexeme,0,MAX_LEX_ERROR);
                return tkn;
            }    
            break;

            case 2:;
            c=get_char(fp);
            if(isdigit(c)) state=2;
            else if (c=='.') state=3;
            else {
                retract(1);
                 tkn.lineno = line_no;
                int size = current_ptr- start_ptr;
                if(size<0){
                    size += BUFFER_SIZE;
                    if(flag==0){
                        strncpy(lexeme, Buffer2 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer1, current_ptr);
                    }
                    else{
                        strncpy(lexeme, Buffer1 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer2, current_ptr);
                    }
                }
                else{
                    if(flag){
                        strncpy(lexeme,Buffer2+start_ptr, current_ptr-start_ptr);
                    }
                    else{
                        strncpy(lexeme,Buffer1+start_ptr, current_ptr-start_ptr);
                    }
                }
                if(size>20){
                    tkn.name = LEX_ERROR;
                    strncpy(tkn.v.lexeme, lexeme, MAX_LEX_ERROR);   
                }
                else{
                    tkn.name = NUM;
                    tkn.v.numvalue=atoi(lexeme);
                }
                start_ptr = current_ptr;
                state = 0;
                memset(lexeme,0,MAX_LEX_ERROR);
                return tkn;
            }
            break;
            
            case 3:;
            c=get_char(fp);
            if(isdigit(c))
                state=5;
            else if(c=='.')
                state=4;
            else {
                retract(1);
                state=50;
            }
            break;

            case 4:;
            retract(2);
             tkn.lineno = line_no;
                int size = current_ptr- start_ptr;
                if(size<0){
                    size += BUFFER_SIZE;
                    if(flag==0){
                        strncpy(lexeme, Buffer2 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer1, current_ptr);
                    }
                    else{
                        strncpy(lexeme, Buffer1 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer2, current_ptr);
                    }
                }
                else{
                    if(flag){
                        strncpy(lexeme,Buffer2+start_ptr, current_ptr-start_ptr);
                    }
                    else{
                        strncpy(lexeme,Buffer1+start_ptr, current_ptr-start_ptr);
                    }
                }
                if(size>20){
                    tkn.name = LEX_ERROR;
                    strncpy(tkn.v.lexeme, lexeme, MAX_LEX_ERROR);   
                }
                else{
                    tkn.name = NUM;
                    tkn.v.numvalue = atoi(lexeme);
                }
                start_ptr = current_ptr;
                state = 0;
                memset(lexeme,0,MAX_LEX_ERROR);
                return tkn;
            break;
            
            case 5:;
            c=get_char(fp);
            if(isdigit(c))
                state=5;
            else if(c=='e'||c=='E')
                state=6;
            else{
                retract(1);
                tkn.lineno = line_no;
                int size = current_ptr- start_ptr;
                if(size<0){
                    size += BUFFER_SIZE;
                    if(flag==0){
                        strncpy(lexeme, Buffer2 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer1, current_ptr);
                    }
                    else{
                        strncpy(lexeme, Buffer1 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer2, current_ptr);
                    }
                }
                else{
                    if(flag){
                        strncpy(lexeme,Buffer2+start_ptr, current_ptr-start_ptr);
                    }
                    else{
                        strncpy(lexeme,Buffer1+start_ptr, current_ptr-start_ptr);
                    }
                }
                if(size>20){
                    tkn.name = LEX_ERROR;
                    strncpy(tkn.v.lexeme, lexeme, MAX_LEX_ERROR);   
                }
                else{
                    tkn.name = RNUM;
                    tkn.v.rnumvalue=atof(lexeme);
                }
                start_ptr = current_ptr;
                state = 0;
                memset(lexeme,0,MAX_LEX_ERROR);
                return tkn;
            }
            break;

            case 6:;
            c=get_char(fp);
            if(c=='+'||c=='-')
                state=8;
            else if(isdigit(c))
                state=7;
            else state=50;
            break;
            
            case 7:;
            c=get_char(fp);
            if(isdigit(c)) state=7;
            else {
                retract(1);
                tkn.lineno = line_no;
                int size = current_ptr- start_ptr;
                if(size<0){
                    size += BUFFER_SIZE;
                    if(flag==0){
                        strncpy(lexeme, Buffer2 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer1, current_ptr);
                    }
                    else{
                        strncpy(lexeme, Buffer1 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer2, current_ptr);
                    }
                }
                else{
                    if(flag){
                        strncpy(lexeme,Buffer2+start_ptr, current_ptr-start_ptr);
                    }
                    else{
                        strncpy(lexeme,Buffer1+start_ptr, current_ptr-start_ptr);
                    }
                }
                if(size>20){
                    tkn.name = LEX_ERROR;
                    strncpy(tkn.v.lexeme, lexeme, MAX_LEX_ERROR);   
                }
                else{
                    tkn.name = RNUM;
                    tkn.v.rnumvalue=atof(lexeme);
                }
                start_ptr = current_ptr;
                state = 0;
                memset(lexeme,0,MAX_LEX_ERROR);
                return tkn;
            }
            break;
            
            case 8:;
            c=get_char(fp);
            if(isdigit(c)) state=7;
            else state=50;
            break;

            case 9:;
            tkn.name=PLUS;
            strncpy(tkn.v.lexeme,"+",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            case 10:;
            tkn.name=MINUS;
            strncpy(tkn.v.lexeme,"-",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            case 11:;
            c=get_char(fp);
            if(c=='*') state=12;
            else {
                retract(1);
                tkn.name=MUL;
                strncpy(tkn.v.lexeme,"*",MAX_LEXEME_LENGTH);
                start_ptr= current_ptr;
                state=0;
                return tkn;
            }
            break;

            case 12:;
            c=get_char(fp);
            if(c!='*'){
                state =12;
                if(c=='\n')line_no++;
            }
            else {
                state=13;
            }
            break;
            
            case 13:;
            c = get_char(fp);
            if(c=='*') state =14;
            else state=12;
            break;

            case 14:;
            start_ptr=current_ptr;
            state=0;
            break;
    
            case 15:;
            tkn.name=DIV;
            strncpy(tkn.v.lexeme,"/",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            case 16:;
            c=get_char(fp);
            if(c=='=') state =17;
            else if(c=='<') state=18;
            else{
                retract(1);
                tkn.name=LT;
                strncpy(tkn.v.lexeme,"<",MAX_LEXEME_LENGTH);
                start_ptr= current_ptr;
                state=0;
                return tkn;
            }
            break;

            case 17:;
            tkn.name=LE;
            strncpy(tkn.v.lexeme,"<=",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            case 18:;
            c=get_char(fp);
            if(c=='<') state=19;
            else {
                retract(1);
                tkn.name=DEF;
                strncpy(tkn.v.lexeme,"<<",MAX_LEXEME_LENGTH);
                start_ptr= current_ptr;
                state=0;
                return tkn;
            }
            break;
            
            case 19:;
            tkn.name=DRIVERDEF;
            strncpy(tkn.v.lexeme,"<<<",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            case 20:;
            c=get_char(fp);
            if(c=='=') state =21;
            else if(c=='>') state=22;
            else{
                retract(1);
                tkn.name=GT;
                strncpy(tkn.v.lexeme,">",MAX_LEXEME_LENGTH);
                start_ptr= current_ptr;
                state=0;
                return tkn;
            }
            break;

            case 21:;
            tkn.name=GE;
            strncpy(tkn.v.lexeme,">=",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            case 22:;
            c=get_char(fp);
            if(c=='>') state=23;
            else {
                retract(1);
                tkn.name=ENDDEF;
                strncpy(tkn.v.lexeme,">>",MAX_LEXEME_LENGTH);
                start_ptr= current_ptr;
                state=0;
                return tkn;
            }
            break;
            
            case 23:;
            tkn.name=DRIVERENDDEF;
            strncpy(tkn.v.lexeme,">>>",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            case 24:;
            c=get_char(fp);
            if(c=='=') state=25;
            else state=50;
            break;

            case 25:;
            tkn.name=EQ;
            strncpy(tkn.v.lexeme,"==",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            case 26:;
            c=get_char(fp);
            if(c=='=')state=27;
            else state=50;
            break;

            case 27:;
            tkn.name=NE;
            strncpy(tkn.v.lexeme,"==",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;


            case 28:;
            c=get_char(fp);
            if(c=='=')state=29;
            else{
                retract(1);
                tkn.name=COLON;
                strncpy(tkn.v.lexeme,":",MAX_LEXEME_LENGTH);
                start_ptr= current_ptr;
                state=0;
                return tkn;
            }
            break;

            case 29:;
            tkn.name=ASSIGNOP;
            strncpy(tkn.v.lexeme,":=",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            
            case 30:;
            c=get_char(fp);
            if(c=='.')state=31;
            else state=50;
            break;

            case 31:;
            tkn.name=RANGEOP;
            strncpy(tkn.v.lexeme,"..",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            case 32:;
            tkn.name=SEMICOL;
            strncpy(tkn.v.lexeme,";",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            case 33:;
            tkn.name=COMMA;
            strncpy(tkn.v.lexeme,",",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;


            case 34:;
            tkn.name=SQBO;
            strncpy(tkn.v.lexeme,"[",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;


            case 35:;
            tkn.name=SQBC;
            strncpy(tkn.v.lexeme,"]",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;
            
            
            case 36:;
            tkn.name=BO;
            strncpy(tkn.v.lexeme,"(",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;


            
            case 37:;
            tkn.name=BC;
            strncpy(tkn.v.lexeme,")",MAX_LEXEME_LENGTH);
            start_ptr= current_ptr;
            state=0;
            return tkn;
            break;

            
            case 50:;
            retract(1);
                tkn.lineno = line_no;
                size = current_ptr- start_ptr;
                if(size<0){
                    size += BUFFER_SIZE;
                    if(flag==0){
                        strncpy(lexeme, Buffer2 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer1, current_ptr);
                    }
                    else{
                        strncpy(lexeme, Buffer1 + start_ptr,BUFFER_SIZE-current_ptr);
                        strncat(lexeme, Buffer2, current_ptr);
                    }
                }
                else{
                    if(flag){
                        strncpy(lexeme,Buffer2+start_ptr, current_ptr-start_ptr);
                    }
                    else{
                        strncpy(lexeme,Buffer1+start_ptr, current_ptr-start_ptr);
                    }
                }
                tkn.name=LEX_ERROR;
                strncpy(tkn.v.lexeme,lexeme,MAX_LEX_ERROR);
                start_ptr = current_ptr;
                state = 0;
                memset(lexeme,0,MAX_LEX_ERROR);
                return tkn;
            break;


            case 49:;
            tkn.name=EOF;
            strncpy(tkn.v.lexeme,"eof",MAX_LEXEME_LENGTH);
            start_ptr=current_ptr;
            state=0;
            return tkn;
            break;    
        }
    }
}

void tokenize_source_file(char *filename) { 
  memset(Buffer1,0,BUFFER_SIZE);
  memset(Buffer2,0,BUFFER_SIZE);
   state = 0;
 start_ptr = 0;
 current_ptr = 0;
 line_no = 1;
 flag = 0;
 retractf= 0;
  FILE* source=fopen(filename, "r");
  TOKEN tkn;
  line_no=1;
  fread(Buffer1,1, BUFFER_SIZE, source);
  printf("%-15s  |  %-20s  |  %-20s\n", "LINE_NUMBER", "LEXEME", "TOKEN_NAME");

  if (source == NULL) {
    printf("source null : print token stream\n");
  }

  while (true) {
    tkn = get_next_token(source);
    printf("\n");
    if (tkn.name == EOF) {
      break;
    } else {
        cute_print(tkn);
      }
    }
}

void cute_print(TOKEN tkn){
     if (tkn.name == LEX_ERROR) {
        printf("************************************************************\n");
        printf("%-15d  |  %-20s  |  %-20s\n", tkn.lineno, tkn.v.lexeme,
               "LEXICAL_ERROR");
        printf("************************************************************\n");
      } else {
          printf("%-15d  |  ", tkn.lineno);
          switch (tkn.name) {
          case NUM:
            printf("%-20d  |  ", tkn.v.numvalue);
            break;
          case RNUM:
            printf("%-20f  |  ", tkn.v.rnumvalue);
            break;
          default:
            printf("%-20s  |  ", tkn.v.lexeme);
            break;
          }
          printf("%-20s\n", terminal_string[tkn.name]);
      }
}

