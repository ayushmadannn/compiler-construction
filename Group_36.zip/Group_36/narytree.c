/*
            ******GROUP NUMBER 36*******
            AKSHAT AGRAWAL 2020A7PS0994P
            MADHAV GUPTA   2020A7PS0106P
            ANISH GUPTA    2020A7PS2051P
            AYUSH MADAN    2020A7PS0090P
*/

#include<stdio.h>
#include<stdlib.h>
// #include "lexerDef.h"
FILE*parseptr;

struct Node{
    int value;
    struct Node *child;
    struct Node *sibling;
    struct Node *parent;
};

struct Node *newNode(struct Node* parent,int key){
    struct Node *node = malloc(sizeof(struct Node));
    node->value=key;
    node->child=NULL;
    node->sibling=NULL;
    node->parent=parent;
    return node;
}

void insert_sibling(struct Node*parent,struct Node*first,int array[],int size,int cur){
    
    if(cur==size){
        return;
    }
    first->sibling=newNode(parent,array[cur]);
    cur++;
    insert_sibling(parent,first->sibling,array,size,cur);
}

void insertChildren(struct Node* parent,int array[],int size){
    parent->child=newNode(parent,array[0]);
    insert_sibling(parent,parent->child,array,size,1);
}

int parsenodecounter=0;
void printParseTree(struct Node* root){
    if(root==NULL) return ;
    printParseTree(root->child);

    printf("%s->",terminal_string[root->value]);
    parsenodecounter++;
    printParseTree(root->sibling);
}
