/*
            ******GROUP NUMBER 36*******
            AKSHAT AGRAWAL 2020A7PS0994P
            MADHAV GUPTA   2020A7PS0106P
            ANISH GUPTA    2020A7PS2051P
            AYUSH MADAN    2020A7PS0090P
*/

#include<stdio.h>
#include<stdlib.h>
#define INT_MAX -1

typedef struct
{
    int top;
    int st_size;
    int *values;
} Stack;

Stack *create_stack(){
    Stack *stack_pt = (Stack *)malloc(sizeof(Stack));
    if(stack_pt==NULL){
        printf("stack not initialized\n");
    }
    stack_pt->top = -1;
    stack_pt->st_size = 100;
    stack_pt->values = (int *)malloc(stack_pt->st_size * sizeof(int));
    if (stack_pt->values == NULL){
        printf("stack values not initialized\n");
    }
    return stack_pt;
}

void free_stack(Stack *stack_pt){
    free(stack_pt->values);
    free(stack_pt);
}

int stack_empty(Stack *stack_pt){
    if(stack_pt->top==-1) return 1;
    return 0;
}

void stackPush(Stack* stack_start, int element){
    if (stack_start->top == stack_start->st_size)
        stack_start->st_size *= 10;

    int* temp = realloc(stack_start->values, sizeof(int) * stack_start->st_size);

    if(temp==NULL)
        printf("stack size didn't increase!");
    else
        stack_start->values = temp;

    stack_start->top++;
    stack_start->values[stack_start->top] = element;
}

int stackPop(Stack *stack_start)
{
    if (stack_empty(stack_start)) // checking if the stack is empty
        return INT_MAX;

    stack_start->top--;
    return stack_start->values[stack_start->top];
}

int stackTop(Stack *stack_start){
    if (stack_empty(stack_start))
        return INT_MAX;

    return stack_start->values[stack_start->top];
}