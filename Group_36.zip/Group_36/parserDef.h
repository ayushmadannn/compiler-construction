/*
            ******GROUP NUMBER 36*******
            AKSHAT AGRAWAL 2020A7PS0994P
            MADHAV GUPTA   2020A7PS0106P
            ANISH GUPTA    2020A7PS2051P
            AYUSH MADAN    2020A7PS0090P
*/

#ifndef PARSERDEF_H
#define PARSERDEF_H

#include "hashtable.h"

#define NO_OF_RULES 148
#define MAX_GRAMMAR_LENGTH 15
#define NUM_terminals 59
#define NUM_nonterminals 76
// #define BUFFER_SIZE 1024

int first[NUM_nonterminals][NUM_terminals];
int follow[NUM_nonterminals][NUM_terminals];
int parse_table[NUM_nonterminals][NUM_terminals+NUM_nonterminals];
int last_index[NO_OF_RULES];
int grammar[NO_OF_RULES][MAX_GRAMMAR_LENGTH];


DataItem* symbol_table[HASH_SIZE];

#endif
