/*
            ******GROUP NUMBER 36*******
            AKSHAT AGRAWAL 2020A7PS0994P
            MADHAV GUPTA   2020A7PS0106P
            ANISH GUPTA    2020A7PS2051P
            AYUSH MADAN    2020A7PS0090P
*/

#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <stdio.h>
#include "hashtableDef.h"

int hashCode(char *str);

int search(DataItem* *table, char *str);

void insert(DataItem* *table, char *str, int value);

#endif
