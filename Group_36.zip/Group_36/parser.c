/*
            ******GROUP NUMBER 36*******
            AKSHAT AGRAWAL 2020A7PS0994P
            MADHAV GUPTA   2020A7PS0106P
            ANISH GUPTA    2020A7PS2051P
            AYUSH MADAN    2020A7PS0090P
*/


#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h> 
#include <ctype.h>
#include "stack.c"
#include "parserDef.h"
#include "lexer.c"
#include "narytree.c"


int n1=0;
int n2=0;

void followf(int ch, int c);
void next_first(int ch, int c, int c1 , int c2);
void create_parseTable();
void parsing();
void add_follow(int ch,int c);
int ran_check(int n);



void populate_parser_table() {
insert(symbol_table,"MAINPROGRAM",MAINPROGRAM);
insert(symbol_table,"MODULEDECLARATIONS",MODULEDECLARATIONS);
insert(symbol_table,"OTHERMODULES",OTHERMODULES);
insert(symbol_table,"DRIVERMODULE",DRIVERMODULE);
insert(symbol_table,"MODULEDECLARATION",MODULEDECLARATION);
insert(symbol_table,"epsilon",EPSILON);
insert(symbol_table,"declare",DECLARE);
insert(symbol_table,"module",MODULE);
insert(symbol_table,"id",ID);
insert(symbol_table,"semicol",SEMICOL);
insert(symbol_table,"MODULENT",MODULENT);
insert(symbol_table,"driverdef",DRIVERDEF);
insert(symbol_table,"driver",DRIVER);
insert(symbol_table,"program",PROGRAM);
insert(symbol_table,"driverenddef",DRIVERENDDEF);
insert(symbol_table,"MODULEDEF",MODULEDEF);
insert(symbol_table,"def",DEF);
insert(symbol_table,"enddef",ENDDEF);
insert(symbol_table,"takes",TAKES);
insert(symbol_table,"input",INPUT);
insert(symbol_table,"sqbo",SQBO);
insert(symbol_table,"INPUT_PLIST",INPUT_PLIST);
insert(symbol_table,"sqbc",SQBC);
insert(symbol_table,"RET",RET);
insert(symbol_table,"start",START);
insert(symbol_table,"STATEMENTS",STATEMENTS);
insert(symbol_table,"end",END);
insert(symbol_table,"returns",RETURNS);
insert(symbol_table,"OUTPUT_PLIST",OUTPUT_PLIST);
insert(symbol_table,"colon",COLON);
insert(symbol_table,"DATATYPE",DATATYPE);
insert(symbol_table,"INPUT_PLIST_DASH",INPUT_PLIST_DASH);
insert(symbol_table,"comma",COMMA);
insert(symbol_table,"TYPE",TYPE);
insert(symbol_table,"OUTPUT_PLIST_DASH",OUTPUT_PLIST_DASH);
insert(symbol_table,"integer",INTEGER);
insert(symbol_table,"real",REAL);
insert(symbol_table,"boolean",BOOLEAN);
insert(symbol_table,"array",ARRAY);
insert(symbol_table,"RANGE_ARRAYS",RANGE_ARRAYS);
insert(symbol_table,"of",OF);
insert(symbol_table,"INDEX_ARR",INDEX_ARR);
insert(symbol_table,"rangeop",RANGEOP);
insert(symbol_table,"STATEMENT",STATEMENT);
insert(symbol_table,"IOSTMT",IOSTMT);
insert(symbol_table,"SIMPLESTMT",SIMPLESTMT);
insert(symbol_table,"DECLARESTMT",DECLARESTMT);
insert(symbol_table,"CONDITIONALSTMT",CONDITIONALSTMT);
insert(symbol_table,"ITERATIVESTMT",ITERATIVESTMT);
insert(symbol_table,"get_value",GET_VALUE);
insert(symbol_table,"bo",BO);
insert(symbol_table,"bc",BC);
insert(symbol_table,"print",PRINT);
insert(symbol_table,"VAR_PRINT",VAR_PRINT);
insert(symbol_table,"BOOLCONSTT",BOOLCONSTT);
insert(symbol_table,"true",TRUE);
insert(symbol_table,"false",FALSE);
insert(symbol_table,"ID_NUM_RNUM",ID_NUM_RNUM);
insert(symbol_table,"rnum",RNUM);
insert(symbol_table,"num",NUM);
insert(symbol_table,"ARRAY_ELEMENT_FOR_PRINT",ARRAY_ELEMENT_FOR_PRINT);
insert(symbol_table,"P1",P1);
insert(symbol_table,"NEW_INDEX",NEW_INDEX);
insert(symbol_table,"ASSIGNMENTSTMT",ASSIGNMENTSTMT);
insert(symbol_table,"MODULEREUSESTMT",MODULEREUSESTMT);
insert(symbol_table,"WHICHSTMT",WHICHSTMT);
insert(symbol_table,"LVALUEIDSTMT",LVALUEIDSTMT);
insert(symbol_table,"LVALUEARRSTMT",LVALUEARRSTMT);
insert(symbol_table,"assignop",ASSIGNOP);
insert(symbol_table,"EXPRESSION",EXPRESSION);
insert(symbol_table,"ELEMENT_INDEX_WITH_EXPRESSIONS",ELEMENT_INDEX_WITH_EXPRESSIONS);
insert(symbol_table,"SIGN",SIGN);
insert(symbol_table,"plus",PLUS);
insert(symbol_table,"minus",MINUS);
insert(symbol_table,"OPTIONAL",OPTIONAL);
insert(symbol_table,"use",USE);
insert(symbol_table,"with",WITH);
insert(symbol_table,"parameters",PARAMETERS);
insert(symbol_table,"ACTUAL_PARA_LIST",ACTUAL_PARA_LIST);
insert(symbol_table,"IDLIST",IDLIST);
insert(symbol_table,"K",K);
insert(symbol_table,"T",T);
insert(symbol_table,"ACTUAL_DASH",ACTUAL_DASH);
insert(symbol_table,"N_11",N_11);
insert(symbol_table,"N3",N3);
insert(symbol_table,"ARITHMETICORBOOLEANEXPR",ARITHMETICORBOOLEANEXPR);
insert(symbol_table,"U",U);
insert(symbol_table,"UNARY_OP",UNARY_OP);
insert(symbol_table,"NEW_NT",NEW_NT);
insert(symbol_table,"ARITHMETICEXPR",ARITHMETICEXPR);
insert(symbol_table,"VAR_ID_NUM",VAR_ID_NUM);
insert(symbol_table,"ANYTERM",ANYTERM);
insert(symbol_table,"N7",N7);
insert(symbol_table,"LOGICALOP",LOGICALOP);
insert(symbol_table,"N8",N8);
insert(symbol_table,"RELATIONALOP",RELATIONALOP);
insert(symbol_table,"TERM",TERM);
insert(symbol_table,"N4",N4);
insert(symbol_table,"OP1",OP1);
insert(symbol_table,"FACTOR",FACTOR);
insert(symbol_table,"N5",N5);
insert(symbol_table,"OP2",OP2);
insert(symbol_table,"N_10",N_10);
insert(symbol_table,"ARREXPR",ARREXPR);
insert(symbol_table,"ARRTERM",ARRTERM);
insert(symbol_table,"ARR_N4",ARR_N4);
insert(symbol_table,"ARRFACTOR",ARRFACTOR);
insert(symbol_table,"ARR_N5",ARR_N5);
insert(symbol_table,"mul",MUL);
insert(symbol_table,"div",DIV);
insert(symbol_table,"and",AND);
insert(symbol_table,"or",OR);
insert(symbol_table,"lt",LT);
insert(symbol_table,"le",LE);
insert(symbol_table,"gt",GT);
insert(symbol_table,"ge",GE);
insert(symbol_table,"eq",EQ);
insert(symbol_table,"ne",NE);
insert(symbol_table,"switch",SWITCH);
insert(symbol_table,"CASESTMTS",CASESTMTS);
insert(symbol_table,"DEFAULTNT",DEFAULTNT);
insert(symbol_table,"case",CASE);
insert(symbol_table,"VALUE",VALUE);
insert(symbol_table,"break",BREAK);
insert(symbol_table,"N9",N9);
insert(symbol_table,"default",DEFAULT);
insert(symbol_table,"for",FOR);
insert(symbol_table,"in",IN);
insert(symbol_table,"RANGE_FOR_LOOP",RANGE_FOR_LOOP);
insert(symbol_table,"while",WHILE);
insert(symbol_table,"INDEX_FOR_LOOP",INDEX_FOR_LOOP);
insert(symbol_table,"SIGN_FOR_LOOP",SIGN_FOR_LOOP);
insert(symbol_table,"NEW_INDEX_FOR_LOOP",NEW_INDEX_FOR_LOOP);
insert(symbol_table,"dollar",DOLLAR);
}


int if_t(int ch){
    if(ch<=NUM_nonterminals)return 0;
    else return 1;
}

int if_nt(int ch){
    if(ch<=NUM_nonterminals)return 1;
    else return 0;
}


void populate_grammar(){
    int lhs=0;
    int rhs=0;
    char delimiter_characters[] = " \n";
    const char *filename = "ourgrammar.txt";
    FILE *input_file = fopen( filename, "r" );
    char buffer[ BUFFER_SIZE ];
    char *last_token;

    if( input_file == NULL ){

        fprintf( stderr, "Unable to open file %s\n", filename );

    }else{

        while( fgets(buffer, BUFFER_SIZE, input_file) != NULL ){
            
            last_token = strtok( buffer, delimiter_characters );
            while( last_token != NULL ){
               
                grammar[lhs][rhs++]=search(symbol_table,last_token);
                last_token = strtok( NULL, delimiter_characters );
            }
            // last_index[lhs] = rhs-1;
            lhs++;
            rhs=0;
        }

        if( ferror(input_file) ){
            perror( "The following error occurred" );
        }

        fclose( input_file );
    }   
}

void first_find(int lhs,int ch,int q1,int q2){
    if(if_t(ch))first[lhs][n1++]=ch;
    for(int j=0;j<NO_OF_RULES;j++){
        if(grammar[j][0]==ch){
            if(grammar[j][1]==EPSILON){
                if(grammar[q1][q2]==-1) first[lhs][n1++]=EPSILON;
                else if(q1!=0||q2!=0) first_find(lhs,grammar[q1][q2],q1,q2+1);
                else first[lhs][n1++]=EPSILON;
            }
            else if(if_t(grammar[j][1])) first[lhs][n1++]=grammar[j][1];
            else first_find(lhs,grammar[j][1],j,2);
        }
        
    }

}

void followf(int ch,int c)
{
	int i ,j;
	if(c==0){
 		follow[ch][n2++]=DOLLAR;
        return;
 	}
 	for(i=0;i<NO_OF_RULES;i++){
  		for(int j=1;j<MAX_GRAMMAR_LENGTH;j++){
   			if(grammar[i][j]==c){   
    			if(grammar[i][j+1]!=-1)
					next_first(ch,grammar[i][j+1],i,(j+2));
    			else if(grammar[i][j+1]==-1&&c!=grammar[i][0])
     				followf(ch,grammar[i][0]);
   			}   
  		}
 	}
}

void next_first(int ch, int c, int c1 , int c2)
{
    int k;
    if(if_t(c)){
        add_follow(ch,c);
    }
	else{
        int r=ran_check(ch/10);
		int j=0;
		while(first[c][j] != -1){
			if(first[c][j] != EPSILON)
                add_follow(ch,first[c][j]);
			else{
				if(grammar[c1][c2] == -1)
					followf(ch,grammar[c1][0]);
				else
					next_first(ch, grammar[c1][c2],c1,c2+1);
			}
			j++;
		}
	}
}

void add_follow(int ch,int c){
    int flag=0;
    for(int z=0;z<NUM_terminals;z++)
        if(follow[ch][z]==c)flag=1;
    if(flag==0)
		follow[ch][n2++]=c;
}



void calc_first(){
    int count=NO_OF_RULES;
    for(int i=0;i<count;i++){
        int lhs=grammar[i][0];
        if(first[lhs][0]==-1){
            first_find(lhs,lhs,0,0);
            n1=0;
        }
    }
}



void calc_follow(){
    int count=NO_OF_RULES;
    for(int i=0;i<count;i++){
        int lhs=grammar[i][0];
        if(follow[i][0]==-1){
            followf(i,i);
            n2=0;
        }
    }
}

int ran_check(int n){
    if(n==0) return 0;
    else if(n==1)return 1;
    else return ran_check(n-1)+ran_check(n-2);
}

struct Node* trRoot;
void parsing(char*fname){
	Stack *my_stack = create_stack();
    struct Node* treeRoot = newNode(NULL, MAINPROGRAM);
    struct Node* root = treeRoot;
    stackPush(my_stack, MAINPROGRAM);
    FILE *source = fopen(fname, "r");
    fread(Buffer1,1, BUFFER_SIZE, source);
    TOKEN curr = get_next_token(source);
    symbol_name tkn = curr.name;
    
	while(!stack_empty(my_stack)){
        
		int top = stackTop(my_stack);
       
		if(if_t(top) && top == tkn){
			stackPop(my_stack);
			curr = get_next_token(source);
                    if(root->sibling!=NULL)
                    root = root->sibling;
                    else{
                    while((root->parent)->sibling == NULL)
                        root = (root->parent);
                    root = (root->parent)->sibling;
				    }
			tkn = curr.name;
		}
		else if(if_t(top) && top != tkn){
			printf("===============================================================\n");
            printf("Syntactical Error because Stack Terminal and Token Mismatch\n");
			printf("===============================================================\n");
            break;
		}
		else if(stack_empty(my_stack) && tkn != EOF){
			printf("===============================================================\n");
            printf("Syntactical Error because Stack is empty before EOF\n");
			printf("===============================================================\n");
            break;		
		}
		else if(if_nt(top) && (tkn ==EOF || parse_table[top][tkn]==-1)){
			int i=0;
			int f=0;
			while(first[top][i]!=-1){
                
				if(first[top][i]==EPSILON){
					stackPop(my_stack);
					f=1;
                    root->child = newNode(root, EPSILON);
                    if(root->sibling!=NULL)
                    root = root->sibling;
                    else{
                        int brk=0;
                    if((root->parent)->value == 0){
                        brk=1;
                        break;
                    }    
                    while((root->parent)->sibling == NULL){
                        
                        root = (root->parent);
                        if((root->parent)->value == 0){
                            brk=1;
                            break;
                        }
                    }
                    if(brk==1) break;
                    root = (root->parent)->sibling;
				    }
					break;
				}
                i++;
			}
			if(f==0){
                printf("===============================================================\n");
				printf("Syntactic Error Because token cant be reached from the non terminal at top of the stack\n");
				printf("===============================================================\n");
                break;
			}
		}
        else if(tkn==EOF && grammar[parse_table[stackTop(my_stack)][DOLLAR]][1]==EPSILON){
            stackPop(my_stack);
            root->child = newNode(root, EPSILON);
                    if(root->sibling!=NULL)
                    root = root->sibling;
                    else{
                        while((root->parent)->sibling == NULL)
                        root = (root->parent);
                        root = (root->parent)->sibling;
				    }
        }
        else if(if_nt(top) && parse_table[top][tkn]!=-1){
			int x = parse_table[top][tkn];
			stackPop(my_stack);
            
			for(int i=last_index[x];i>0;i--){
				if(grammar[x][i]==EPSILON){
                    root->child = newNode(root, EPSILON);
                    if(root->sibling!=NULL)
                    root = root->sibling;
                    else{
                    while((root->parent)->sibling == NULL)
                        root = (root->parent);
                    root = (root->parent)->sibling;
				    }



					break;
				}
				stackPush(my_stack, grammar[x][i]);
			}
            int size = last_index[x];
            int arr[size];
            for(int i=1;i<=last_index[x];i++){
                arr[i-1] = grammar[x][i];
            }
            if(grammar[x][1]!=EPSILON){
            insertChildren(root,arr,size);
            root = root->child;
            }
		}
	}
    
    if(stack_empty(my_stack) && tkn == EOF){
        printf("===============================================================\n");
		printf("Input source code is syntactically correct..........\n");
        printf("===============================================================\n");
        trRoot=treeRoot;
        printParseTree(treeRoot);

	}
}


int fl=0;
void fill_table(int ch, int c,int i, int x){

    if(if_t(c)){
        parse_table[ch][c]=i;
        return;
    }
    if(grammar[i][x]==-1){

        fl=1;
        return;
    }
    int j=0;
    while(first[c][j]!=-1){
        if(first[c][j]==EPSILON){
            fill_table(ch,grammar[i][x+1],i,x+1);
            break;
        }
        else{
            parse_table[ch][first[c][j]] = i;
            
        }
        j++;
    }
    return;
}


void create_parseTable(){
    for(int i=0;i<NO_OF_RULES;i++){
        int nt = grammar[i][0];
            if(i==46)printf("%d\n",nt);

        if(if_t(grammar[i][1])){
            parse_table[nt][grammar[i][1]] = i;
        }
        
        else if(grammar[i][1]==EPSILON){
            int k=0;
            while(follow[grammar[i][0]][k]!=-1){
                  parse_table[nt][follow[grammar[i][0]][k]] = i;
                k++;
            }
        }
        else if(if_nt(grammar[i][1]) && grammar[i][1]!=EPSILON){

            fill_table(nt, grammar[i][1],i, 1);
            if(fl==1){
                int k=0;
                while(follow[grammar[i][0]][k]!=-1){
                parse_table[nt][follow[grammar[i][0]][k]] = i;
                k++;
                }
            }
            
        }
    }
}
    