/*
            ******GROUP NUMBER 36*******
            AKSHAT AGRAWAL 2020A7PS0994P
            MADHAV GUPTA   2020A7PS0106P
            ANISH GUPTA    2020A7PS2051P
            AYUSH MADAN    2020A7PS0090P
*/


#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "hashtableDef.h"


int hashCode(char *str){
   
    unsigned long hash = 5381;
        int c;

        while (c = *str++)
            hash = ((hash << 5) + hash) + c; 

        return ((hash%HASH_SIZE)+HASH_SIZE)%HASH_SIZE;
}

int search(DataItem* *table,char *str){

    int hashIndex=hashCode(str);
    while(table[hashIndex]!=NULL){
        
        if(strcmp(table[hashIndex]->lexeme,str)==0)
            return (table[hashIndex]->value);
        ++hashIndex;
        hashIndex%=HASH_SIZE;
    }
    
    return KEY_NOT_FOUND;
}

void insert(DataItem* *table,char *str, int value){
    DataItem *item = malloc(sizeof(DataItem));
    strncpy(item->lexeme,str,MAX_LEXEME_LENGTH); 
    item->value = value;
    
    int hashIndex=hashCode(str);
    while(table[hashIndex]!=NULL ){
        hashIndex++;
        hashIndex%=HASH_SIZE;
    }
    table[hashIndex]=item;

}
