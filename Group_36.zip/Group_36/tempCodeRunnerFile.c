for(int i=0;i<NUM_nonterminals;i++){
                for(int j=0;j<NUM_terminals;j++){
                    printf("%d ",follow[i][j]);
                }
                printf("\n");
            }