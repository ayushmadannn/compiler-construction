/*
            ******GROUP NUMBER 36*******
            AKSHAT AGRAWAL 2020A7PS0994P
            MADHAV GUPTA   2020A7PS0106P
            ANISH GUPTA    2020A7PS2051P
            AYUSH MADAN    2020A7PS0090P
*/

#ifndef LEXER_H
#define LEXER_H

#include "lexerDef.h"

#include <stdio.h>

void populate_lexer_table();

void retract(int number);

void fill_buffer(FILE *fp);

char get_char(FILE *fp);

TOKEN get_next_token(FILE *file_name);

void tokenize_source_file(char *source) ;

void remove_comments(char *file_name,char*clean_file);

void cute_print(TOKEN tkn);


#endif