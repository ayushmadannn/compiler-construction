/*
            ******GROUP NUMBER 36*******
            AKSHAT AGRAWAL 2020A7PS0994P
            MADHAV GUPTA   2020A7PS0106P
            ANISH GUPTA    2020A7PS2051P
            AYUSH MADAN    2020A7PS0090P
*/

#ifndef HASHTABLEDEF_H
#define HASHTABLEDEF_H

#define KEY_NOT_FOUND -1
#define HASH_SIZE 29791
#define MAX_LEXEME_LENGTH 1024


typedef struct {
    char lexeme[MAX_LEXEME_LENGTH];
    int value;
}DataItem;

struct DataItem* hashArray[HASH_SIZE];

#endif
