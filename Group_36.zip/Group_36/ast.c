#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "parser.c"

typedef struct astNode {
    symbol_name nodeType;
    struct astNode* parent;
    struct astNode* firstChild;
    struct astNode* sib;
    //g_Term symbol;
    //symbol_name name;
    char* lexeme;
    int line;
    bool is_union;
}ast;

ast* createNode(symbol_name nodeType, ast* parent, ast* firstChild, ast* nextSibling, struct Node* ptNode) {
    ast* node = (ast*)malloc(sizeof(ast));
    node->nodeType = nodeType;
    node->parent = parent;
    node->firstChild = firstChild;
    node->sib = nextSibling;
    // node->symbol = ptNode->symbol;
    // node->lexeme = ptNode->lex;
    // node->line = ptNode->lineNo;
    node->is_union = false;
    return node;
}

ast* createAST(struct Node* ptNode, ast* parent) {
    // printf("%d\n",ptNode->value);
    ast* curr, *temp1,*head;
    if(ptNode->child->value== EPSILON){
        //printf("hola\n");
        return NULL;
        // return createNode(EPSILON,NULL,NULL,NULL,NULL);
    }

    // MAINPROGRAM MODULEDECLARATIONS OTHERMODULES DRIVERMODULE OTHERMODULES
    if(ptNode->value == MAINPROGRAM){
        head = createNode(MAINPROGRAM, parent, NULL, NULL, ptNode);
        curr = head;
        curr->firstChild = createAST(ptNode->child, curr);
        if(curr->firstChild == NULL){
            curr->firstChild = createAST(ptNode->child->sibling,curr);
            temp1 = curr->firstChild;
        }
        else{
            curr->firstChild->sib = createAST(ptNode->child->sibling,curr);
            temp1 = curr->firstChild->sib;
        }
        if(temp1 == NULL){
            temp1 = createAST(ptNode->child->sibling->sibling,curr);
        }
        else{
            temp1->sib= createAST(ptNode->child->sibling->sibling,curr);
            temp1= temp1->sib;
        }
        temp1->sib = createAST(ptNode->child->sibling->sibling->sibling,curr);
    }

    // MODULEDECLARATIONS MODULEDECLARATION MODULEDECLARATIONS
    if(ptNode->value == MODULEDECLARATIONS) {
        if(ptNode->child->value == MODULEDECLARATION) {
            curr = createAST(ptNode->child, parent);
            curr->sib= createAST(ptNode->child->sibling, parent);
        }
    }

    // MODULEDECLARATION declare module id semicol
    if(ptNode->value == MODULEDECLARATION){
        curr = createNode(ID, parent , NULL, NULL,ptNode->child->sibling->sibling->sibling );
    }

    // OTHERMODULES MODULENT OTHERMODULES
    if(ptNode->value == OTHERMODULES) {
        if(ptNode->child->value == MODULENT) {
            curr = createAST(ptNode->child, parent);
               

            temp1= createAST(ptNode->child->sibling, parent);
                

            if(temp1!=NULL) curr->sib=temp1;
              
        }
    }

    // DRIVERMODULE driverdef driver program driverenddef MODULEDEF
    if(ptNode->value == DRIVERMODULE){
        curr = createAST(ptNode->child->sibling->sibling->sibling->sibling, parent);
    }

    //MODULENT def module id enddef takes input sqbo INPUT_PLIST sqbc semicol RET MODULEDEF
    if(ptNode->value == MODULENT){
        curr = createNode(ID, parent , NULL, NULL,ptNode->child->sibling->sibling);
        curr->firstChild = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling->sibling,curr);
        temp1 = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling->sibling->sibling->sibling->sibling,curr);
        if(temp1!=NULL) temp1->sib =createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling->sibling->sibling->sibling->sibling->sibling,curr);
        else temp1= createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling->sibling->sibling->sibling->sibling->sibling,curr);
    }
    // MODULEDEF start STATEMENTS end 
    if(ptNode->value == MODULEDEF){
        curr = createAST(ptNode->child->sibling, parent);
    }

    // RET returns sqbo OUTPUT_PLIST sqbc semicol
    if(ptNode->value == RET){
        curr = createAST(ptNode->child->sibling->sibling, parent);
    }

    // INPUT_PLIST id colon DATATYPE INPUT_PLIST_DASH
    if(ptNode->value == INPUT_PLIST){
        curr = createNode(ID, parent, NULL,NULL, ptNode->child);
        curr->firstChild = createAST(ptNode->child->sibling->sibling, curr);

        //curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling, curr);
        temp1 = createAST(ptNode->child->sibling->sibling->sibling, curr);
        if(temp1!=NULL) curr->firstChild->sib = temp1;
    }

    // INPUT_PLIST_DASH comma id colon DATATYPE INPUT_PLIST_DASH
    if(ptNode->value == INPUT_PLIST_DASH){

        curr = createNode(ID, parent, NULL,NULL, ptNode->child->sibling);
        curr->firstChild = createAST(ptNode->child->sibling->sibling->sibling, curr);
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling, curr);
    }

    // OUTPUT_PLIST id colon TYPE OUTPUT_PLIST_DASH
    if(ptNode->value == OUTPUT_PLIST){
        curr = createNode(ID, parent, NULL,NULL, ptNode->child);
        curr->firstChild = createAST(ptNode->child->sibling->sibling, curr);
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling, curr);
    }

    // OUTPUT_PLIST_DASH comma id colon TYPE OUTPUT_PLIST_DASH
    if(ptNode->value == OUTPUT_PLIST_DASH){
        curr = createNode(ID, parent, NULL,NULL, ptNode->child->sibling);
        curr->firstChild = createAST(ptNode->child->sibling->sibling->sibling, curr);
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling, curr);
    }

    if(ptNode->value == DATATYPE){
        switch(ptNode->child->value) {
            case INTEGER:
                curr = createNode(INTEGER, parent, NULL, NULL, ptNode->child);
                break;
            case REAL:
                curr = createNode(REAL, parent, NULL, NULL, ptNode->child);
                break;
            case BOOLEAN:
                curr = createNode(BOOLEAN, parent, NULL, NULL, ptNode->child);
                break;
            // HOW TO
            case ARRAY:
                curr = createAST(ptNode->child->sibling->sibling, parent);

        }
    }


    // RANGE_ARRAYS INDEX_ARR rangeop INDEX_ARR
    if(ptNode->value == RANGE_ARRAYS){
        curr = createNode(RANGEOP,parent , NULL, NULL, ptNode->child->sibling);
        curr->firstChild = createAST(ptNode->child, curr);
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling, curr);
   
    }

    // TYPE integer
    // TYPE real
    // TYPE boolean
    if(ptNode->value == TYPE){
        switch(ptNode->child->value){
            case INTEGER:
                curr = createNode(INTEGER, parent, NULL, NULL, ptNode->child);
                break;
            case REAL:
                curr = createNode(REAL, parent, NULL, NULL, ptNode->child);
                break;
            case BOOLEAN:
                curr = createNode(BOOLEAN, parent, NULL, NULL, ptNode->child);
                break;
        }
    }

    // STATEMENTS STATEMENT STATEMENTS
    if(ptNode->value == STATEMENTS) {
        if(ptNode->child->value == STATEMENT) {
            curr = createAST(ptNode->child, parent);
            temp1= createAST(ptNode->child->sibling, parent);
            if(temp1!=NULL) curr->sib = temp1;
        }
    }

    // STATEMENT IOSTMT
    // STATEMENT SIMPLESTMT
    // STATEMENT DECLARESTMT
    // STATEMENT CONDITIONALSTMT
    // STATEMENT ITERATIVESTMT
    if(ptNode->value == STATEMENT){
        switch(ptNode->child->value){
            case IOSTMT:
                curr = createAST(ptNode->child, parent);
                break;
            case SIMPLESTMT:
                curr = createAST(ptNode->child, parent);
                break;
            case DECLARESTMT:
                curr = createAST(ptNode->child, parent);
                break;
            case CONDITIONALSTMT:
                curr = createAST(ptNode->child, parent);
                break;
            case ITERATIVESTMT:
                curr = createAST(ptNode->child, parent);
                break;        
        }
    }
    
    // IOSTMT get_value bo id bc semicol
    // IOSTMT print bo VAR_PRINT bc semicol
    if(ptNode->value == IOSTMT){
        if(ptNode->child->value == GET_VALUE)
        curr = createNode(ID, parent , NULL, NULL,ptNode->child->sibling->sibling);
        if(ptNode->child->value == PRINT)
        curr = createAST(ptNode->child->sibling->sibling, parent);
        
    }

    // BOOLCONSTT true 
    // BOOLCONSTT false

    if(ptNode->value == BOOLCONSTT){
        switch(ptNode->child->value){
            case true:
                curr = createNode(TRUE, parent , NULL, NULL,ptNode->child);
                break;
            case false:
                curr = createNode(FALSE, parent , NULL, NULL,ptNode->child);
                break;        
        }
    }

    // ID_NUM_RNUM id
    // ID_NUM_RNUM rnum
    // ID_NUM_RNUM num

    if(ptNode->value == ID_NUM_RNUM){
        switch(ptNode->child->value){
            case ID:
                curr = createNode(ID, parent , NULL, NULL,ptNode->child);
                break;
            case RNUM:
                curr = createNode(RNUM, parent , NULL, NULL,ptNode->child);
                break;
            case NUM:
                curr = createNode(NUM, parent , NULL, NULL,ptNode->child);
                break;   
                      
        }
    }

    // ARRAY_ELEMENT_FOR_PRINT id sqbo INDEX_ARR sqbc
    if(ptNode->value == ARRAY_ELEMENT_FOR_PRINT){
        curr = createNode(ID, parent, NULL, NULL, ptNode->child);
        curr->firstChild = createAST(ptNode->child->sibling->sibling, curr);
    }

    //VAR_PRINT id P1
    if(ptNode->value == VAR_PRINT){
        if(ptNode->child->value == ID){
        curr = createNode(ID, parent, NULL, NULL, ptNode->child);
        curr->firstChild = createAST(ptNode->child->sibling, curr);
        }
        // VAR_PRINT BOOLCONSTT
        // VAR_PRINT num
        // VAR_PRINT rnum
        else{
            switch(ptNode->child->value){
            case BOOLCONSTT:
                curr = createAST(ptNode->child, parent);
                break;
            case RNUM:
                curr = createNode(RNUM, parent , NULL, NULL,ptNode->child);
                break;
            case NUM:
                curr = createNode(NUM, parent , NULL, NULL,ptNode->child);
                break;   
                      
            }
        }
    }
    
    // P1 sqbo INDEX_ARR sqbc
    if(ptNode->value == P1){
        curr = createAST(ptNode->child->sibling, parent);
    }
    
    // SIMPLESTMT ASSIGNMENTSTMT
    // SIMPLESTMT MODULEREUSESTMT
    if(ptNode->value == SIMPLESTMT){
        switch(ptNode->child->value){
            case ASSIGNMENTSTMT:
                curr = createAST(ptNode->child, parent);
                break;
            case MODULEREUSESTMT:
                curr = createAST(ptNode->child, parent);
                break;
                    
        }
    }

    // ASSIGNMENTSTMT id WHICHSTMT
    if(ptNode->value == ASSIGNMENTSTMT){  
        curr = createNode(ID, parent, NULL, NULL, ptNode->child);
        temp1 = createAST(ptNode->child->sibling,NULL);
        if(temp1){
            ast* temp2 = temp1->firstChild;
            temp1->firstChild = curr;
            temp1->firstChild->parent = temp1;
            temp1->firstChild->sib = temp2;
            temp1->firstChild->sib->parent = temp1;
            while(temp1->parent != NULL) {
                temp1 = temp1->parent;
            }
            curr = temp1;
        }
    }

    // WHICHSTMT LVALUEIDSTMT
    // WHICHSTMT LVALUEARRSTMT
    if(ptNode->value == WHICHSTMT){
        curr = createAST(ptNode->child, parent);
    }

    // LVALUEIDSTMT assignop EXPRESSION semicol
    if(ptNode->value == LVALUEIDSTMT){
        curr = createNode(ASSIGNOP, parent, NULL, NULL, ptNode->child);
        curr->firstChild = createAST(ptNode->child->sibling, curr);
    }

    // LVALUEARRSTMT sqbo ELEMENT_INDEX_WITH_EXPRESSIONS sqbc assignop EXPRESSION semicol
    if(ptNode->value == LVALUEARRSTMT){
        curr = createNode(ASSIGNOP, parent, NULL,NULL, ptNode->child->sibling->sibling->sibling);
        curr->firstChild = createAST(ptNode->child->sibling->sibling->sibling->sibling, curr);
        curr->firstChild->sib = createAST(ptNode->child->sibling, curr);
    }

    // INDEX_ARR SIGN NEW_INDEX
    if(ptNode->value == INDEX_ARR){
        curr = createAST(ptNode->child, parent);
        if(curr == NULL){
            curr = createAST(ptNode->child->sibling,parent);
        }
        else{
            curr->firstChild = createAST(ptNode->child->sibling,parent);
        }
    }

    // NEW_INDEX num
    // NEW_INDEX id
    if(ptNode->value == NEW_INDEX){
        switch(ptNode->child->value){
            case NUM:
                curr = createNode(NUM, parent , NULL, NULL,ptNode->child);
                break;
            case ID:
                curr = createNode(ID, parent , NULL, NULL,ptNode->child);
                break;
                    
        }
    }

    // SIGN plus
    // SIGN minus
    if(ptNode->value == SIGN){
        switch(ptNode->child->value){
            case PLUS:
                curr = createNode(PLUS, parent , NULL, NULL,ptNode->child);
                break;
            case MINUS:
                curr = createNode(MINUS, parent , NULL, NULL,ptNode->child);
                break;            
        }
    }
    
    //MODULEREUSESTMT OPTIONAL use module id with parameters ACTUAL_PARA_LIST semicol
    if(ptNode->value == MODULEREUSESTMT){
        curr = createNode(MODULEREUSESTMT, parent, NULL, NULL, ptNode->child);
        temp1 = createAST(ptNode->child,curr);
        if(temp1!=NULL) curr->firstChild = temp1;
        if(curr->firstChild!=NULL){
            curr->firstChild->sib = createNode(ID, curr, NULL, NULL, ptNode->child->sibling->sibling->sibling);
            
            curr->firstChild->sib->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling, curr);
            
        }
        else{
            curr->firstChild = createNode(ID, curr, NULL, NULL, ptNode->child->sibling->sibling->sibling);
            curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling, curr);
        }
    }
    // OPTIONAL sqbo IDLIST sqbc assignop
    if(ptNode->value == OPTIONAL){
        curr = createNode(ASSIGNOP, parent, NULL, NULL, ptNode->child->sibling->sibling->sibling);
        curr->firstChild = createAST(ptNode->child->sibling,curr);
    }

    // ACTUAL_PARA_LIST T ACTUAL_DASH 
    if(ptNode->value == ACTUAL_PARA_LIST){
        curr = createAST(ptNode->child, parent);
        curr->firstChild = createAST(ptNode->child->sibling,parent);
    }

    // ACTUAL_DASH comma T ACTUAL_DASH
    if(ptNode->value == ACTUAL_DASH){
        curr = createAST(ptNode->child->sibling, parent);
        curr->firstChild = createAST(ptNode->child->sibling->sibling,parent);
    }

    // T SIGN K
    if(ptNode->value == T){
        if(ptNode->child->value == SIGN){
            curr = createAST(ptNode->child, parent);
            if(curr == NULL){
                curr = createAST(ptNode->child->sibling,parent);
            }
            else{
                curr->firstChild = createAST(ptNode->child->sibling,parent);
            }
        }
        else{
            curr = createAST(ptNode->child,parent);
        }
    }
    
    // K num
    // K rnum
    // K BOOLCONSTT
    // K id N_11
    if(ptNode->value == K){
        if(ptNode->child->value == ID){
        curr = createNode(ID, parent, NULL, NULL, ptNode->child);
        curr->firstChild = createAST(ptNode->child->sibling, curr);
        }
        // VAR_PRINT BOOLCONSTT
        // VAR_PRINT num
        // VAR_PRINT rnum
        else{
            switch(ptNode->child->value){
            case BOOLCONSTT:
                curr = createAST(ptNode->child, parent);
                break;
            case RNUM:
                curr = createNode(RNUM, parent , NULL, NULL,ptNode->child);
                break;
            case NUM:
                curr = createNode(NUM, parent , NULL, NULL,ptNode->child);
                break;   
                      
            }
        }
    }

    //N_11 sqbo ELEMENT_INDEX_WITH_EXPRESSIONS sqbc
    if(ptNode->value == N_11){
        curr = createAST(ptNode->child->sibling, parent);
    }

    // IDLIST id N3
    if(ptNode->value == IDLIST){
        curr = createNode(ID, parent, NULL, NULL, ptNode->child);
        temp1 = createAST(ptNode->child->sibling, curr);
        if(temp1!=NULL) curr->firstChild = temp1;
    }

    //N3 comma id N3
    if(ptNode->value == N3){
        curr = createNode(ID, parent, NULL, NULL, ptNode->child);
        temp1 = createAST(ptNode->child->sibling, curr);
        if(temp1!=NULL) curr->sib=temp1;
    }

    //EXPRESSION ARITHMETICORBOOLEANEXPR 
    // EXPRESSION U 
    if(ptNode->value == EXPRESSION){
        curr = createAST(ptNode->child, parent);
    }

    // U UNARY_OP NEW_NT
    if(ptNode->value == U){
        curr = createAST(ptNode->child,parent);
        curr->firstChild = createAST(ptNode->child->sibling,curr);
    }
    
    // NEW_NT bo ARITHMETICEXPR bc
    // NEW_NT VAR_ID_NUM
    if(ptNode->value == NEW_NT){
        if(ptNode->child->value == BO){
            curr = createAST(ptNode->child->sibling,parent);
        }
        else{
            curr = createAST(ptNode->child, parent);
        }
    }

    // VAR_ID_NUM id
    // VAR_ID_NUM num
    // VAR_ID_NUM rnum
    if(ptNode->value == VAR_ID_NUM){
        switch(ptNode->child->value){
            case ID:
                curr = createNode(ID, parent , NULL, NULL,ptNode->child);
                break;
            case RNUM:
                curr = createNode(RNUM, parent , NULL, NULL,ptNode->child);
                break;
            case NUM:
                curr = createNode(NUM, parent , NULL, NULL,ptNode->child);
                break;   
                      
        }
    }

    // UNARY_OP plus
    // UNARY_OP minus
    if(ptNode->value == UNARY_OP){
        switch(ptNode->child->value){
            case PLUS:
                curr = createNode(PLUS, parent , NULL, NULL,ptNode->child);
                break;
            case MINUS:
                curr = createNode(MINUS, parent , NULL, NULL,ptNode->child);
                break;            
        }
    }

    // ARITHMETICORBOOLEANEXPR ANYTERM N7
    if(ptNode->value == ARITHMETICORBOOLEANEXPR){
        curr = createAST(ptNode->child,parent);
        temp1 = createAST(ptNode->child->sibling,NULL);
        if(temp1){
            ast* temp2 = temp1->firstChild;
            temp1->firstChild = curr;
            temp1->firstChild->parent = temp1;
            temp1->firstChild->sib = temp2;
            temp1->firstChild->sib->parent = temp1;
            while(temp1->parent != NULL) {
                temp1 = temp1->parent;
            }
            curr = temp1;
        }
    }

    //  N7 LOGICALOP ANYTERM N7
    if(ptNode->value == N7){
        curr = createAST(ptNode->child, parent);
        curr->firstChild = createAST(ptNode->child->sibling, curr);
        temp1 = createAST(ptNode->child->sibling->sibling, parent);
        if(temp1) {
            ast* temp2 = temp1->firstChild;
            temp1->firstChild = curr;
            curr->parent = temp1;
            curr->sib = temp2;
            temp2->parent = temp1;
            curr = temp1->firstChild;
            return curr;
        }
    }
    
    // ANYTERM ARITHMETICEXPR N8
    if(ptNode->value == ANYTERM){
        if(ptNode->child->value == ARITHMETICEXPR){
            curr = createAST(ptNode->child,parent);
            temp1 = createAST(ptNode->child->sibling,NULL);
            if(temp1){
            ast* temp2 = temp1->firstChild;
            temp1->firstChild = curr;
            temp1->firstChild->parent = temp1;
            temp1->firstChild->sib = temp2;
            temp1->firstChild->sib->parent = temp1;
            while(temp1->parent != NULL) {
                temp1 = temp1->parent;
            }
            curr = temp1;
        }
        }
        else{
            curr = createAST(ptNode->child, parent);
        }
    }

    // N8 RELATIONALOP ARITHMETICEXPR
    if(ptNode->value == N8){
         curr = createAST(ptNode->child, parent);
        curr->firstChild = createAST(ptNode->child->sibling, curr);    
    }

    // ARITHMETICEXPR TERM N4 
    if(ptNode->value == ARITHMETICEXPR){
        curr = createAST(ptNode->child,parent);
        temp1 = createAST(ptNode->child->sibling,NULL);
        if(temp1){
            ast* temp2 = temp1->firstChild;
            temp1->firstChild = curr;
            temp1->firstChild->parent = temp1;
            temp1->firstChild->sib = temp2;
            temp1->firstChild->sib->parent = temp1;
            while(temp1->parent != NULL) {
                temp1 = temp1->parent;
            }
            curr = temp1;
        }
    }

    // N4 OP1 TERM N4
    if(ptNode->value == N4){
        curr = createAST(ptNode->child, parent);
        curr->firstChild = createAST(ptNode->child->sibling, curr);
        temp1 = createAST(ptNode->child->sibling->sibling, parent);
        if(temp1) {
            ast* temp2 = temp1->firstChild;
            temp1->firstChild = curr;
            curr->parent = temp1;
            curr->sib = temp2;
            temp2->parent = temp1;
            curr = temp1->firstChild;
            return curr;
        }
    }

    // TERM FACTOR N5 
    if(ptNode->value == TERM){
        curr = createAST(ptNode->child,parent);
        // printf("y\n");

        temp1 = createAST(ptNode->child->sibling,NULL);
        // printf("y\n");
        
        if(temp1!=NULL){
        // printf("y\n");
        // printf("Z\n");

            ast* temp2 = temp1->firstChild;
        // printf("Z\n");

            temp1->firstChild = curr;
        // printf("Z\n");

            temp1->firstChild->parent = temp1;
            temp1->firstChild->sib = temp2;
            temp1->firstChild->sib->parent = temp1;
            while(temp1->parent != NULL) {
                temp1 = temp1->parent;
            }
            curr = temp1;
        }
        // printf("Z\n");
    }

    // N5 OP2 FACTOR N5
    if(ptNode->value == N5){
        // printf("X\n");
        curr = createAST(ptNode->child, parent);
        // printf("X\n");
        curr->firstChild = createAST(ptNode->child->sibling, curr);
        // printf("X\n");

        temp1 = createAST(ptNode->child->sibling->sibling, parent);
        
        // printf("X\n");

        if(temp1!=NULL && temp1->firstChild !=NULL) {
            ast* temp2 = temp1->firstChild;
            temp1->firstChild = curr;
            curr->parent = temp1;
            curr->sib = temp2;
            temp2->parent = temp1;
            curr = temp1->firstChild;
            return curr;
        }
        // printf("X");
    }

    // line 100
    // FACTOR bo ARITHMETICORBOOLEANEXPR bc
    // FACTOR num
    // FACTOR rnum
    // FACTOR id N_11
    // FACTOR BOOLCONSTT
    if(ptNode->value == FACTOR){
        if(ptNode->child->value == BO){
            curr = createAST(ptNode->child->sibling, parent);
        }
        else if(ptNode->child->value == ID){
            curr = createNode(ID, parent,NULL,NULL,ptNode->child);
            curr->firstChild = createAST(ptNode->child->sibling,curr);
        }
        else{
            switch(ptNode->child->value){
            case BOOLCONSTT:
                curr = createAST(ptNode->child, parent);
                break;
            case RNUM:
                curr = createNode(RNUM, parent , NULL, NULL,ptNode->child);
                break;
            case NUM:
                curr = createNode(NUM, parent , NULL, NULL,ptNode->child);
                break;   
                      
            }
        }
    }

    // N_11 sqbo ELEMENT_INDEX_WITH_EXPRESSIONS sqbc 
    if(ptNode->value == N_11){
        curr = createAST(ptNode->child->sibling,parent);
    } 

    //ELEMENT_INDEX_WITH_EXPRESSIONS SIGN N_10
    //ELEMENT_INDEX_WITH_EXPRESSIONS ARREXPR
    if(ptNode->value == ELEMENT_INDEX_WITH_EXPRESSIONS){
        if(ptNode->child->value == SIGN){
            curr = createAST(ptNode->child, parent);
            if(curr == NULL){
                curr = createAST(ptNode->child->sibling,parent);
            }
            else{
                curr->firstChild = createAST(ptNode->child->sibling,parent);
            }
        }
        else{
            curr = createAST(ptNode->child,parent);
        }
    }

    //N_10 NEW_INDEX
    //N_10 bo ARREXPR bC
    if(ptNode->value  == N_10){
        if(ptNode->child->value == NEW_INDEX){
            curr = createAST(ptNode->child,parent);
        }
        else{
            curr = createAST(ptNode->child->sibling,parent);
        }
    }

    // ARREXPR ARRTERM ARR_N4
    if(ptNode->value == ARREXPR){
        curr = createAST(ptNode->child,parent);
        temp1 = createAST(ptNode->child->sibling,NULL);
        if(temp1){
            ast* temp2 = temp1->firstChild;
            temp1->firstChild = curr;
            temp1->firstChild->parent = temp1;
            temp1->firstChild->sib = temp2;
            temp1->firstChild->sib->parent = temp1;
            while(temp1->parent != NULL) {
                temp1 = temp1->parent;
            }
            curr = temp1;
        }
    }

    //ARR_N4 OP1 ARRTERM ARR_N4 
    if(ptNode->value == ARR_N4){
        curr = createAST(ptNode->child, parent);
        curr->firstChild = createAST(ptNode->child->sibling, curr);
        temp1 = createAST(ptNode->child->sibling->sibling, parent);
        if(temp1) {
            ast* temp2 = temp1->firstChild;
            temp1->firstChild = curr;
            curr->parent = temp1;
            curr->sib = temp2;
            temp2->parent = temp1;
            curr = temp1->firstChild;
            return curr;
        }
    }

    // ARRTERM ARRFACTOR ARR_N5
    if(ptNode->value == ARRTERM){
        curr = createAST(ptNode->child,parent);
        temp1 = createAST(ptNode->child->sibling,NULL);
        if(temp1){
            ast* temp2 = temp1->firstChild;
            temp1->firstChild = curr;
            temp1->firstChild->parent = temp1;
            temp1->firstChild->sib = temp2;
            temp1->firstChild->sib->parent = temp1;
            while(temp1->parent != NULL) {
                temp1 = temp1->parent;
            }
            curr = temp1;
        }
    }

    //ARR_N5 OP2 ARRFACTOR ARR_N5
    if(ptNode->value == ARR_N5){
        curr = createAST(ptNode->child, parent);
        curr->firstChild = createAST(ptNode->child->sibling, curr);
        temp1 = createAST(ptNode->child->sibling->sibling, parent);
        if(temp1) {
            ast* temp2 = temp1->firstChild;
            temp1->firstChild = curr;
            curr->parent = temp1;
            curr->sib = temp2;
            temp2->parent = temp1;
            curr = temp1->firstChild;
            return curr;
        }
    }


    // ARRFACTOR id
    // ARRFACTOR num
    // ARRFACTOR BOOLCONSTT
    // ARRFACTOR bo ARREXPR bc

    if(ptNode->value == ARRFACTOR){
        if(ptNode->child->value == BO){
            curr = createAST(ptNode->child->sibling, parent);
        }
        else{
            switch(ptNode->child->value){
            case BOOLCONSTT:
                curr = createAST(ptNode->child, parent);
                break;
            case RNUM:
                curr = createNode(RNUM, parent , NULL, NULL,ptNode->child);
                break;
            case NUM:
                curr = createNode(NUM, parent , NULL, NULL,ptNode->child);
                break;   
                      
            }
        }
    }

    // OP1 plus
    // OP1 minus

    if(ptNode->value == OP1){
        switch(ptNode->child->value){
            case PLUS:
                curr = createNode(PLUS, parent , NULL, NULL,ptNode->child);
                break;
            case MINUS:
                curr = createNode(MINUS, parent , NULL, NULL,ptNode->child);
                break;            
        }
    }
    
    // OP2 mul
    // OP2 div

    if(ptNode->value == OP2){
        switch(ptNode->child->value){
            case MUL:
                curr = createNode(MUL, parent , NULL, NULL,ptNode->child);
                break;
            case DIV:
                curr = createNode(DIV, parent , NULL, NULL,ptNode->child);
                break;            
        }
    }

    // LOGICALOP and
    // LOGICALOP or

    if(ptNode->value == LOGICALOP){
        switch(ptNode->child->value){
            case AND:
                curr = createNode(AND, parent , NULL, NULL,ptNode->child);
                break;
            case OR:
                curr = createNode(OR, parent , NULL, NULL,ptNode->child);
                break;            
        }
    }

    // RELATIONALOP lt
    // RELATIONALOP le
    // RELATIONALOP gt
    // RELATIONALOP ge
    // RELATIONALOP eq
    // RELATIONALOP ne

    if(ptNode->value == RELATIONALOP){
        switch(ptNode->child->value){
            case LT:
                curr = createNode(LT, parent , NULL, NULL,ptNode->child);
                break;
            case LE:
                curr = createNode(LE, parent , NULL, NULL,ptNode->child);
                break;
            case GT:
                curr = createNode(GT, parent , NULL, NULL,ptNode->child);
                break;
            case GE:
                curr = createNode(GE, parent , NULL, NULL,ptNode->child);
                break;  
            case EQ:
                curr = createNode(EQ, parent , NULL, NULL,ptNode->child);
                break;
            case NE:
                curr = createNode(NE, parent , NULL, NULL,ptNode->child);
                break;              
        }
    }

    // DECLARESTMT declare IDLIST colon DATATYPE semicol
    if(ptNode->value == DECLARESTMT){
        curr = createNode(DECLARESTMT, parent, NULL, NULL, ptNode->child);
        curr->firstChild = createAST(ptNode->child->sibling,curr);
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling,curr);
    }

    // CONDITIONALSTMT switch bo id bc start CASESTMTS DEFAULTNT end
    if(ptNode->value == CONDITIONALSTMT){
        curr = createNode(CONDITIONALSTMT, parent,NULL,NULL,ptNode->child);
        curr->firstChild = createNode(ID, curr, NULL, NULL, ptNode->child->sibling->sibling);
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling,curr);
        curr->firstChild->sib->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling,curr);
    }

    // CASESTMTS case VALUE colon STATEMENTS break semicol N9
    if(ptNode->value == CASESTMTS){
        curr = createNode(CASESTMTS, parent,NULL, NULL,ptNode->child->sibling);
        curr->firstChild = createAST(ptNode->child->sibling, curr);
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling, curr);
        if(curr->firstChild->sib == NULL){
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling, curr);

        }
        else{
        curr->firstChild->sib->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling, curr);
        }
    }

    //N9 case VALUE colon STATEMENTS break semicol N9
    if(ptNode->value == N9){
        curr = createNode(CASESTMTS, parent,NULL, NULL,ptNode->child->sibling);
        curr->firstChild = createAST(ptNode->child->sibling, curr);
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling, curr);
        if(curr->firstChild->sib == NULL){
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling, curr);

        }
        else{
        curr->firstChild->sib->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling, curr);
        }
    }

    // VALUE num
    // VALUE true
    // VALUE false
    if(ptNode->value == VALUE){
        switch(ptNode->child->value){
            case true:
                curr = createNode(TRUE, parent , NULL, NULL,ptNode->child);
                break;
            case false:
                curr = createNode(FALSE, parent , NULL, NULL,ptNode->child);
                break;
            case NUM:
                curr = createNode(NUM, parent , NULL, NULL,ptNode->child); 
                break;       
        }
    }

    // DEFAULTNT default colon STATEMENTS break semicol 
    if(ptNode->value == DEFAULTNT){
        curr = createAST(ptNode->child->sibling->sibling,parent);
    }

    //  ITERATIVESTMT for bo id in RANGE_FOR_LOOP bc start STATEMENTS end
    if(ptNode->value == ITERATIVESTMT && ptNode->child->value == FOR){
        curr = createNode(ITERATIVESTMT, parent, NULL, NULL, ptNode->child);
        curr->firstChild = createNode(ID, curr, NULL,NULL, ptNode->child->sibling->sibling);
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling,curr);
        curr->firstChild->sib->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling->sibling->sibling,curr);
    }

    //RANGE_FOR_LOOP INDEX_ARR rangeop INDEX_ARR
    if(ptNode->value == RANGE_FOR_LOOP){
        curr = createNode(RANGEOP,parent , NULL, NULL, ptNode->child->sibling);
        curr->firstChild = createAST(ptNode->child, curr);
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling, curr);
    }

    // ITERATIVESTMT while bo ARITHMETICORBOOLEANEXPR bc start STATEMENTS end
    if(ptNode->value == ITERATIVESTMT && ptNode->child->value == WHILE){
        curr = createNode(ITERATIVESTMT, parent, NULL, NULL, ptNode->child);
        curr->firstChild = createAST(ptNode->child->sibling->sibling,curr);
        curr->firstChild->sib = createAST(ptNode->child->sibling->sibling->sibling->sibling->sibling,curr);
    }
    
    //INDEX_FOR_LOOP SIGN_FOR_LOOP NEW_INDEX_FOR_LOOP
    if(ptNode->value == INDEX_FOR_LOOP){
        curr = createAST(ptNode->child, parent);
        if(curr == NULL){
            curr = createAST(ptNode->child->sibling,parent);
        }
        else{
            curr->firstChild = createAST(ptNode->child->sibling,parent);
        }
    }

    //NEW_INDEX_FOR_LOOP num
    if(ptNode->value == NEW_INDEX_FOR_LOOP){
        curr = createNode(NUM,parent,NULL,NULL,ptNode->child);
    }

    // SIGN_FOR_LOOP plus
    //SIGN_FOR_LOOP minus
    if(ptNode->value == SIGN_FOR_LOOP){
        switch(ptNode->child->value){
            case PLUS:
                curr = createNode(PLUS, parent , NULL, NULL,ptNode->child);
                break;
            case MINUS:
                curr = createNode(MINUS, parent , NULL, NULL,ptNode->child);
                break;            
        }
    }
    return head;
}   

ast* initAST(struct Node* root) {
    return createAST(root, NULL);
}

// char* nodeTypeToStr(symbol_name nodeType) {
//     return terminal_string[nodeType];
// }
int astnodecounter;
void inorderAST(ast* root)
{


    if(root==NULL) return ;
    inorderAST(root->firstChild);

    printf("%s->",terminal_string[root->nodeType]);
    astnodecounter++;
    inorderAST(root->sib);
    // if (curr == NULL)
    //     return;
    // ast* temp = (ast*)malloc(sizeof(ast));
    // temp = curr->firstChild;
    // if (temp != NULL)
    // {
    //     while (temp->sib)
    //     {
    //         inorderAST(temp, numNodes, fp);
    //         temp = temp->sib;
    //     }
    // }
    // char* valueStr, *lex1, *parentStr, *isLeaf, *nodeSymbol;
    // printf("hi");
    // // if(curr->nodeType == NUM || curr->nodeType == RNUM)
    // //     valueStr = curr->lex;
    // // else
    // //     valueStr = "Not a number ";
    // // if(curr->symbol >= eps)
    // //     lex1 = curr->lex;
    // // else
    // //     lex1 = "------";
    // if(curr->parent!=NULL)
    //     parentStr = terminal_string[(curr->parent)->nodeType];
    // else
    //     parentStr = "ROOT ";
    // if(curr->firstChild!=NULL)
    //     {isLeaf = "NO "; nodeSymbol = terminal_string[curr->nodeType];}
    // else 
    //     {isLeaf = "YES "; nodeSymbol = "Leaf node ";}
    // // if(curr->name == )
    // //     lex1 = "------";
    // printf("\n%25s %15d %30s %20s %25s %10s %25s", lex1, curr->line, terminal_string[curr->nodeType], valueStr, parentStr, isLeaf, nodeSymbol);
    // // fprintf(fp, "\n%25s %15d %30s %20s %25s %10s %25s", lex1, curr->line, nodeTypeToStr(curr->nodeType), valueStr, parentStr, isLeaf, nodeSymbol);
    // *numNodes = *numNodes + 1;
    // inorderAST(temp, numNodes, fp);
}





