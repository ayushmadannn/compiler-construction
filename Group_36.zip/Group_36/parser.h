/*
            ******GROUP NUMBER 36*******
            AKSHAT AGRAWAL 2020A7PS0994P
            MADHAV GUPTA   2020A7PS0106P
            ANISH GUPTA    2020A7PS2051P
            AYUSH MADAN    2020A7PS0090P
*/

#ifndef PARSER_H
#define PARSER_H

#include "parserDef.h"

#include <stdio.h>

void populate_parser_table();

int if_t(int ch);

int if_nt(int ch);

void populate_grammar();

void first_find(int lhs,int ch,int q1,int q2);

void followf(int ch,int c);

void next_first(int ch, int c, int c1 , int c2);

void add_follow(int ch,int c);

void calc_first();

void calc_follow();

int ran_check(int n);

void parsing(char*fname, char *foutname);

void fill_table(int ch, int c,int i, int x);

void create_parseTable();


#endif